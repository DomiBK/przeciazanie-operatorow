﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PrzeciazenieOperatory
{
    using System;

    public class Osoba
    {
        public string Imie { get; }
        public string Nazwisko { get; }
        public string Adres { get; }

        public Osoba(string imie, string nazwisko, string adres)
        {
            Imie = imie;
            Nazwisko = nazwisko;
            Adres = adres;
        }

        // Przeciążanie operatora "<"
        public static bool operator <(Osoba osoba1, Osoba osoba2)
        {
            int compareImie = string.Compare(osoba1.Imie, osoba2.Imie, StringComparison.Ordinal);
            if (compareImie < 0)
                return true;
            else if (compareImie == 0)
                return string.Compare(osoba1.Nazwisko, osoba2.Nazwisko, StringComparison.Ordinal) < 0;
            else
                return false;
        }

        // Przeciążanie operatora ">"
        public static bool operator >(Osoba osoba1, Osoba osoba2)
        {
            int compareImie = string.Compare(osoba1.Imie, osoba2.Imie, StringComparison.Ordinal);
            if (compareImie > 0)
                return true;
            else if (compareImie == 0)
                return string.Compare(osoba1.Nazwisko, osoba2.Nazwisko, StringComparison.Ordinal) > 0;
            else
                return false;
        }

        // Przeciążanie operatora "=="
        public static bool operator ==(Osoba osoba1, Osoba osoba2)
        {
            return osoba1.Imie == osoba2.Imie && osoba1.Nazwisko == osoba2.Nazwisko;
        }

        // Przeciążanie operatora "!="
        public static bool operator !=(Osoba osoba1, Osoba osoba2)
        {
            return !(osoba1 == osoba2);
        }

    }

}
