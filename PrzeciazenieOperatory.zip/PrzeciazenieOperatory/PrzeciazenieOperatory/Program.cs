﻿using PrzeciazenieOperatory;

Osoba osoba1 = new Osoba("Jan", "Kowalski", "ul. Klonowa 1");
Osoba osoba2 = new Osoba("Anna", "Nowak", "ul. Lipowa 2");
Osoba osoba3 = new Osoba("Jan", "Kowalski", "ul. Brzozowa 3");


Console.WriteLine("Porównywanie osób:");
Console.WriteLine($"Osoba1 < Osoba2: {osoba1 < osoba2}");
Console.WriteLine($"Osoba1 > Osoba2: {osoba1 > osoba2}");
Console.WriteLine($"Osoba1 == Osoba2: {osoba1 == osoba2}");
Console.WriteLine($"Osoba1 == Osoba3: {osoba1 == osoba3}");
Console.WriteLine($"Osoba1 != Osoba2: {osoba1 != osoba2}");
Console.WriteLine($"Osoba1 != Osoba3: {osoba1 != osoba3}");